package miPaquete;

class MiError extends Exception {
    public MiError() {}
    public MiError(String msg) {
      super(msg);
    }
}