package miPaquete;

public class Cell {
	String cell;
	String contents;
	
	
	public Cell(String cell, String contents) {
		super();
		this.cell = cell;
		this.contents = contents;
	}
	
	public String getCell() {
		return cell;
	}
	public void setCell(String cell) {
		this.cell = cell;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	
	
	
}
