package exceptions;

public class NonExistingCustomer extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
