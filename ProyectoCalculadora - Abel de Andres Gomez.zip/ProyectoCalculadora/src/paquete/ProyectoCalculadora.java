package paquete;

public class ProyectoCalculadora {
	public static int Add(String numbers){
		if(numbers==""){
			return 0;
		}else{
			int suma=0;
			char chara=numbers.charAt(0);
			if(!Character.isDigit(chara)){
				if(numbers.charAt(1)=='\n'){
					for(int i=2;i<numbers.length();i++){
						if(numbers.charAt(i)!=chara){
							char caracter = numbers.charAt(i);
							int valor= Character.getNumericValue(caracter);
							System.out.println(valor);
							suma+=valor;
						}
					}
				}
			}else{
				for(int i=0;i<numbers.length();i++){
					if(numbers.charAt(i)!=';'){
						char caracter = numbers.charAt(i);
						int valor= Character.getNumericValue(caracter);
						System.out.println(valor);
						suma+=valor;
					}
				}	
			}	
			return suma;
		}	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String suma="6,3,2";
		System.out.println(Add(suma));
	}

}
