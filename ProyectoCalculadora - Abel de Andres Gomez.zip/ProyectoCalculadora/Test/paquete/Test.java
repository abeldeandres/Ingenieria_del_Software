package paquete;

import static org.junit.Assert.*;

public class Test {

	ProyectoCalculadora calculadora = new ProyectoCalculadora();
	
	@org.junit.Test
	public void SumaSencilla() {
		String suma="6,3,2";
		assertEquals(11,calculadora.Add(suma));
	}
	
	@org.junit.Test
	//Hacemos una suma sencilla teniendo en cuenta un string vacio
	public void testSumaSencillaStringNull() {
		String suma="";
		assertEquals(0,calculadora.Add(suma));
	}
	
	@org.junit.Test
	//Hacemos una suma sencilla cambiando el delimitador por ;
	public void testSumaSencillaCambioDelimitador() {
		String suma="6;3;2";
		assertEquals(11,calculadora.Add(suma));
	}
	
	/*
	 * Una vez que funciona la aplicacion para cualquier delimitador
	 * es necesario crear la funcion que permita poder elegir el delimitador que se quiere usar
	 * para ello. 
	 */
	@org.junit.Test
	public void testSumaSencillaDelimitador() {
		String suma="6,3,2";
		assertEquals(11,calculadora.Add(suma));
	}
	
	@org.junit.Test
	public void testSumaSencillaDelimitador1() {
		String suma=";\n6;3;2";
		assertEquals(11,calculadora.Add(suma));
	}
	
	@org.junit.Test
	public void testSumaSencillaDelimitador2() {
		String suma="+\n6+3+2";
		assertEquals(11,calculadora.Add(suma));
	}
	
	@org.junit.Test
	public void testSumaSencillaDelimitador2Error() {
		String suma="+\n6+3+2";
		assertEquals(12,calculadora.Add(suma));
	}
	
	@org.junit.Test
	public void testSumaSencillaDelimitador3() {
		String suma="+\n6+3+2+1+1+1+1+1+1+1+1+1";
		assertEquals(20,calculadora.Add(suma));
	}
	

}
